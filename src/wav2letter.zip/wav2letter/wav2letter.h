#ifndef _WAV2LETTER_PRUNED_H
#define _WAV2LETTER_PRUNED_H

#ifdef __cplusplus
extern "C" {
#endif

void wav2letter_pruned_menu();

#ifdef __cplusplus
}
#endif

#endif  // _WAV2LETTER_PRUNED_H